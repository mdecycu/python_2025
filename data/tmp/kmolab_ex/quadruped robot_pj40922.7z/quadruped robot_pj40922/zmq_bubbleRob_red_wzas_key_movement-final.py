# pip install cbor pyzmq keyboard
# before 4.7.0
#from zmqRemoteApi import RemoteAPIClient
# after 4.7.0 rev4
from coppeliasim_zmqremoteapi_client import RemoteAPIClient
import keyboard
import time

client = RemoteAPIClient('localhost', 23000)

print('Program started')
sim = client.getObject('sim')
sim.startSimulation()
print('Simulation started')

joint_1_1 = sim.getObject('/joint_1_1')
joint_1_2 = sim.getObject('/joint_1_2')
joint_2_1 = sim.getObject('/joint_2_1')
joint_2_2 = sim.getObject('/joint_2_2')
joint_3_1 = sim.getObject('/joint_3_1')
joint_3_2 = sim.getObject('/joint_3_2')
joint_4_1 = sim.getObject('/joint_4_1')
joint_4_2 = sim.getObject('/joint_4_2')
    

    
def setBubbleRobVelocity(target_angle1,target_angle2,target_angle3,target_angle4,target_angle5,target_angle6,target_angle7,target_angle8):
        sim.setJointTargetPosition(joint_1_1, target_angle1 * 3.14159 / 180)
        sim.setJointTargetPosition(joint_1_2, target_angle2 * 3.14159 / 180)
        sim.setJointTargetPosition(joint_2_1, target_angle3 * 3.14159 / 180)
        sim.setJointTargetPosition(joint_2_2, target_angle4 * 3.14159 / 180)
        sim.setJointTargetPosition(joint_3_1, target_angle5 * 3.14159 / 180)
        sim.setJointTargetPosition(joint_3_2, target_angle6 * 3.14159 / 180)
        sim.setJointTargetPosition(joint_4_1, target_angle7 * 3.14159 / 180)
        sim.setJointTargetPosition(joint_4_2, target_angle8 * 3.14159 / 180)


while True:
    if keyboard.is_pressed('q'):
        setBubbleRobVelocity(20,20,-30,0,20,10,-30,0)
        time.sleep(0.5)
        setBubbleRobVelocity(-30,0,20,10,-30,0,20,20)
        time.sleep(1)
    elif keyboard.is_pressed('w'):
        setBubbleRobVelocity(-30,0,20,10,-30,0,20,5)
        time.sleep(0.5)
        setBubbleRobVelocity(20,5,-30,10,20,10,-30,10)
        time.sleep(1)
    elif keyboard.is_pressed('e'):
        setBubbleRobVelocity(-20,40,-10,5,-30,-20,-10,5)
    elif keyboard.is_pressed('r'):
        setBubbleRobVelocity(-0,-20,-0,-20,-0,-20,-0,-20)
    else:
        setBubbleRobVelocity(-10,0,-10,0,-10,0,-10,0)  



